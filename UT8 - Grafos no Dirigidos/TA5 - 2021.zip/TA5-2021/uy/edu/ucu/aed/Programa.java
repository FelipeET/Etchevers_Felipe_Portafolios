package uy.edu.ucu.aed;

import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;

public class Programa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ManejadorArchivosGenerico br = new ManejadorArchivosGenerico();
        String[] lineasVertices = br.leerArchivo("/Users/agustin/Desktop/SEGUNDA PARTE ALG/UT8 GRAFOS NO DIRIGIDOS/ut8-ta3-main/TA3-alumnos (3)/TA3-alumnos/src/main/java/uy/edu/ucu/aed/aristasBEA.txt", false);
        String[] lineasAristas = br.leerArchivo("/Users/agustin/Desktop/SEGUNDA PARTE ALG/UT8 GRAFOS NO DIRIGIDOS/ut8-ta3-main/TA3-alumnos (3)/TA3-alumnos/src/main/java/uy/edu/ucu/aed/verticesBEA.txt", false);

        LinkedList<TVertice> lineasVerticesList = new LinkedList<>();
        for (String listVertices: lineasVertices){
            TVertice vertice = new TVertice<>(listVertices);
            lineasVerticesList.add(listVertices);
        }
        Collection<TVertice> listVertices = Arrays.asList(lineasVertices);
        Collection<TAdyacencia> listAristas = Arrays.asList(lineasVertices);
        TGrafoNoDirigido grafo = new TGrafoNoDirigido(listVertices,listAristas);


        // cargar grafo con actores y relaciones


        // invocar a numBacon como indica la letra y mostrar en consola el resultado


    }


}
