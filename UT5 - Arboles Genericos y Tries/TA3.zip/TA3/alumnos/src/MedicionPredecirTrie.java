public class MedicionPredecirTrie extends Medible{

    private TArbolTrie arbolTrie;

    public MedicionPredecirTrie(TArbolTrie arbolTrie){
        this.arbolTrie = arbolTrie;
    }

    @Override
    public void ejecutar(Object... params) {
        int repeticion = (int) params[0];
        String prefijo = (String) params[2];
        for(int i = 0; i < repeticion; i++){
            arbolTrie.predecir(prefijo);
        }
    }

    @Override
    public Object getObjetoAMedirMemoria() {
        return this.arbolTrie;
    }
}
