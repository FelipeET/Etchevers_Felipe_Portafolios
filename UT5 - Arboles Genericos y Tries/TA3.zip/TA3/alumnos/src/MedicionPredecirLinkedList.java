import java.util.LinkedList;

public class MedicionPredecirLinkedList extends Medible {

    private LinkedList<String> linkedList;

    public MedicionPredecirLinkedList(LinkedList linkedList){
        this.linkedList = linkedList;
    }
    @Override
    public void ejecutar(Object... params) {
        int repeticion = (int) params[0];
        String prefijo = (String) params[2];
        for(int i = 0; i < repeticion; i++){
            this.predecir(prefijo);
        }
    }

    @Override
    public Object getObjetoAMedirMemoria() {
        return this.linkedList;
    }

    public LinkedList<String> predecir(String prefijo){
        LinkedList<String> resultado = new LinkedList<>();
        for (String x : this.linkedList ){
            if(x.startsWith(prefijo)){
                resultado.add(x);
            }
        }
        return resultado;
    }
}
