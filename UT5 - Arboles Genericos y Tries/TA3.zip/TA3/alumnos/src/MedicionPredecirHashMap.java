import java.util.HashMap;
import java.util.LinkedList;

public class MedicionPredecirHashMap extends Medible {

    private HashMap<Integer, String> hashMap;

    public MedicionPredecirHashMap(HashMap <Integer, String> hashMap) {
        this.hashMap = hashMap;
    }

    @Override
    public void ejecutar(Object... params) {

        int repeticion = (int) params[0];
        String prefijo = (String) params[2];
        for(int i = 0; i < repeticion; i++){
            this.predecir(prefijo);
        }
    }

    @Override
    public Object getObjetoAMedirMemoria() {
        return this.hashMap;
    }

    public LinkedList<String> predecir(String prefijo){
        LinkedList<String> resultado = new LinkedList<>();
        for(String x : hashMap.values()){
            if(x.startsWith(prefijo)){
                resultado.add(x);
            }
        }
        return resultado;
    }


}
